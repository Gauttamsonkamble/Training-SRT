function green() {
    var v = document.getElementById("g1");
    v.src = "images/p1.jpg";
}

function red() {
    var v = document.getElementById("g1");
    v.src = "images/p2.jpg";
}